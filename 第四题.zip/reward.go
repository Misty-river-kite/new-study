package main

import (
	"fmt"
	"io"
	"net/http"
)

const (
	jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdGFnZSI6InJld2FyZCIsInNpZCI6ImUzOWUwNjVkNGNlMDc3ZjZiOWM0NGRiMjZmNzJkMjFmIiwiZXhwIjoxNzk1MDYwNzU1LCJpYXQiOjE3OTUwNjAxNTUsImp0aSI6IjU2MWI2ZTIyZDI0NGMyN2E4NDU0YzU0ZThjYzM5OTVhIn0.Kw_Fp5MuXr9R7nBpLHbxPCU0YNmyx4197lKu3_jloe4"
)

func main() {
	client := &http.Client{}

	req, err := http.NewRequest(
		"GET",
		"http://117.72.42.214:8080/api/reward",
		nil,
	)
	if err != nil {
		fmt.Println(err)
		return
	}

	req.Header.Set("Authorization", "Bearer "+jwt)

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)

	fmt.Println(string(body))
}
