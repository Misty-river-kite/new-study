package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"
)

const (
	url = "http://117.72.42.214:8080/api/challenge"
	jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdGFnZSI6ImNoYWxsZW5nZSIsImV4cCI6MTc5NTA2MDUyMywiaWF0IjoxNzk1MDU4NzIzLCJqdGkiOiJlMzllMDY1ZDRjZTA3N2Y2YjljNDRkYjI2ZjcyZDIxZiJ9.CWKAXbpEFXCBm_XQHxyQZ-cHrNdROfsfK_JWZ9tBQdo"
)

type RequestDate struct {
	Seq int `json:"seq"`
}

type Result struct {
	Seq   int
	Statu int
	Body  string
}

func main() {
	var wg sync.WaitGroup
	client := &http.Client{
		Timeout: 5 * time.Second,
	}
	results := make(chan Result, 10)

	seqs := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

	for _, seq := range seqs {
		wg.Add(1)

		go func(seq int) {
			defer wg.Done()

			date := RequestDate{
				Seq: seq,
			}

			dates, err := json.Marshal(date)
			if err != nil {
				fmt.Println(err)
				return
			}

			req, err := http.NewRequest(
				"POST",
				url,
				bytes.NewBuffer(dates),
			)
			if err != nil {
				fmt.Println(err)
				return
			}

			req.Header.Set("Authorization", "Bearer "+jwt)
			req.Header.Set("Content-type", "application/json")

			resp, err := client.Do(req)
			if err != nil {
				fmt.Println(err)
				return
			}
			defer resp.Body.Close()

			body, err := io.ReadAll(resp.Body)
			if err != nil {
				fmt.Println(err)
				return
			}

			results <- Result{
				Seq:   seq,
				Statu: resp.StatusCode,
				Body:  string(body),
			}
		}(seq)
	}

	for result := range results {
		fmt.Println(result)
	}
	wg.Wait()
}
