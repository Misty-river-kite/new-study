package main

import (
	"fmt"

	"github.com/weiji6/hacker-support/encrypt"
	"github.com/weiji6/hacker-support/httptool"
)

const (
	passport = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb2RlIjoiTWlzdHlyaXZlciIsImlhdCI6MTc5NTE3MzA5NywibmJmIjoxNzk1MTczMDk3fQ.8G5bwpG83IL0FPjG5BFdCUbiEOqtiMuVys90ZRg2kzs"
)

func main() {
	req, err := httptool.NewRequest(
		httptool.GETMETHOD,
		"https://gtainmuxi.muxixyz.com/api/v1/organization/code",
		"",
		httptool.DEFAULT, // 这里可能不是 DEFAULT，自己去翻阅文档
	)
	if err != nil {
		fmt.Println(err)
	}

	fmt.Println(req)
	fmt.Println("\n")

	req.AddHeader("alg", "HS256")
	req.AddHeader("typ", "JWT")

	resp, err := req.SendRequest()
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("响应头")
	resp.ShowHeader()

	fmt.Println("响应体")
	resp.ShowBody()
	fmt.Println("\n")

	req2, err := httptool.NewRequest(
		httptool.GETMETHOD,
		"http://http-theft-bank.gtainccnu.muxixyz.com/api/v1/organization/secret_key",
		"",
		httptool.DEFAULT,
	)
	if err != nil {
		fmt.Println(err)
	}

	req2.AddHeader("passport", passport)

	fmt.Println(req2)
	fmt.Println("\n")

	resp2, err := req2.SendRequest()
	fmt.Println("响应头")
	resp2.ShowBody()
	fmt.Println("响应体")

	/*secret, _ := encrypt.Base64Decode("c2VjcmV0X2tleTpNdXhpU3R1ZGlvMjAzMzA0LCBlcnJvcl9jb2RlOmZvciB7Z28gZnVuYygpe3RpbWUuU2xlZXAoMSp0aW1lLkhvdXIpfSgpfQ==")
	fmt.Println(secret)*/

	error_code, err := encrypt.AESEncryptOutInBase64(
		[]byte("for {go func(){time.Sleep(1*time.Hour)}()}"),
		[]byte("MuxiStudio203304"),
	)
	if err != nil {
		fmt.Println(err)
		return
	}

	req3, err := httptool.NewRequest(
		httptool.PUTMETHOD,
		"http://http-theft-bank.gtainccnu.muxixyz.com/api/v1/bank/gate",
		string(error_code),
		httptool.DEFAULT,
	)
	if err != nil {
		fmt.Println(err)
		return
	}

	req3.AddHeader("passport", passport)

	resp3, err := req3.SendRequest()
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("响应头")
	resp3.ShowHeader()
	fmt.Println("响应体")
	resp3.ShowBody()

}
