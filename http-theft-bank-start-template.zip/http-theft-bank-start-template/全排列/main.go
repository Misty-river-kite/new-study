package main

import "fmt"

var n int

