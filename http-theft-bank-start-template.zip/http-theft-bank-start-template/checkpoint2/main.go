package main

import (
	"fmt"

	"github.com/weiji6/hacker-support/httptool"
)

const (
	passport = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb2RlIjoiTWlzdHlyaXZlciIsImlhdCI6MTc5NTE3MzA5NywibmJmIjoxNzk1MTczMDk3fQ.8G5bwpG83IL0FPjG5BFdCUbiEOqtiMuVys90ZRg2kzs"
)

func main() {
	/*req0, err := httptool.NewRequest(
		httptool.GETMETHOD,
		"http://http-theft-bank.gtainccnu.muxixyz.com/api/v1/bank/iris_recognition_gate",
		"",
		httptool.DEFAULT, // 这里可能不是 DEFAULT，自己去翻阅文档
	)
	if err != nil {
		fmt.Println(err)
	}

	req0.AddHeader("passport", passport)

	resp0, err := req0.SendRequest()
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("响应头")
	resp0.ShowHeader()
	fmt.Println("响应体")
	resp0.ShowBody()

	req1, err := httptool.NewRequest(
		httptool.GETMETHOD,
		"http://http-theft-bank.gtainccnu.muxixyz.com/api/v1/organization/iris_sample",
		"",
		httptool.DEFAULT,
	)
	if err != nil {
		fmt.Println(err)
		return
	}

	req1.AddHeader("passport", passport)

	resp1, err := req1.SendRequest()
	if err != nil {
		fmt.Println(err)
		return
	}

	err = resp1.Save("iris_sample.png")
	if err != nil {
		fmt.Println(err)
		return
	}

	req2, err := httptool.NewRequest(
		httptool.POSTMETHOD,
		"http://http-theft-bank.gtainccnu.muxixyz.com/api/v1/bank/iris_recognition_gate",
		"iris_sample.png",
		httptool.FILE,
	)

	req2.AddHeader("passport", passport)

	resq2, err := req2.SendRequest()
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("请求头")
	resq2.ShowHeader()
	fmt.Println("请求体")
	resq2.ShowBody()*/

	req3, err := httptool.NewRequest(
		httptool.GETMETHOD,
		"http://http-theft-bank.gtainccnu.muxixyz.com/api/v1/muxi/backend/computer/examination",
		"",
		httptool.DEFAULT,
	)
	if err != nil {
		fmt.Println(err)
		return
	}

	req3.AddHeader("passport", passport)

	resp, err := req3.SendRequest()
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("请求头")
	resp.ShowHeader()
	fmt.Println("请求体")
	resp.ShowBody()

}
