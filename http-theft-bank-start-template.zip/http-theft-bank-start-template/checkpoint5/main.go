package main

import (
	"fmt"

	"github.com/weiji6/hacker-support/httptool"
)

const (
	passport = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb2RlIjoiTWlzdHlyaXZlciIsImlhdCI6MTc5NTE3MzA5NywibmJmIjoxNzk1MTczMDk3fQ.8G5bwpG83IL0FPjG5BFdCUbiEOqtiMuVys90ZRg2kzs"
)

func main() {
	filepath := "/run/media/Mistyriver/新加卷/木犀/week/http-theft-bank-start-template/全排列/main.go"
	req, err := httptool.NewRequest(
		httptool.POSTMETHOD,
		"http://http-theft-bank.gtainccnu.muxixyz.com/api/v1/muxi/backend/computer/examination",
		filepath,
		httptool.FILE, // 这里可能不是 DEFAULT，自己去翻阅文档
	)
	if err != nil {
		fmt.Println(err)
		return
	}

	req.AddHeader("passport", passport)

	resp, err := req.SendRequest()
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("响应头")
	resp.ShowHeader()
	fmt.Println("响应体")
	resp.ShowBody()
}
